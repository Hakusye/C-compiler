make clean
make
./cmm < $1
./pl0i
