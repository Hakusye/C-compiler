## make fileについて
リンカの部分に -no-pieの引数をつけるとubuntu環境でもmakeするだけで動く

## 
