main{
  var n1;
  var n2;
  var i;
  read n1;
  read n2;
  for i:=0;i<n2;i:=i+1; do
     n1 := n1 + i;
     write n1;
     writeln;
  endfor
}
