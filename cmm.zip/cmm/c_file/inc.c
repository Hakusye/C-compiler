main{
  var n;
  read n;
  n++;
  n++;
  write n++;
  write ++n;
  write n;
  writeln;
}
