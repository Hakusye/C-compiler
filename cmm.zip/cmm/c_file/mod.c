main{
  var n1;
  var n2;
  read n1;
  read n2;
  write n1 % n2;
  writeln;
}
