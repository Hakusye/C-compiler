main{
  var n1;
  var n2;
  read n1;
  write n1 ^ 2;
  writeln;
}
