make
./cmm < fact.c
./pl0i
