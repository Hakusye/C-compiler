/* ------------------------- common.h -------------------------- */
typedef enum { FALSE, TRUE } bool;

extern void error();
extern char *strsave();
extern void cleararray();
