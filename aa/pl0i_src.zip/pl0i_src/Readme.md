ファイル名：code.output

にすると./ploiで動く
tmp_codeにできたコードをいれていく
最終的にtmp_codeをzipして提出する予定
